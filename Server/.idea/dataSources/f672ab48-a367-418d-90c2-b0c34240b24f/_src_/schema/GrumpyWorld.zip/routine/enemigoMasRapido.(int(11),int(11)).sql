CREATE FUNCTION enemigoMasRapido(destrezaRollo INT, destrezaEnemigo INT)
  RETURNS BIT
  BEGIN
	RETURN destrezaEnemigo>destrezaRollo;
END;
