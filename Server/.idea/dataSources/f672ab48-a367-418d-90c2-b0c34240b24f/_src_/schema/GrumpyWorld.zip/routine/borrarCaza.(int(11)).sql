CREATE PROCEDURE borrarCaza(IN idRollo INT)
  BEGIN
	DELETE FROM Caza WHERE ID_Rollo = idRollo;
END;
