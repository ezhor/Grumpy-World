CREATE FUNCTION existeUsuario(nombre_usuario VARCHAR(15))
  RETURNS BIT
  BEGIN
	RETURN (SELECT COUNT(*) FROM Usuarios WHERE Usuario = nombre_usuario)>0;
END;
