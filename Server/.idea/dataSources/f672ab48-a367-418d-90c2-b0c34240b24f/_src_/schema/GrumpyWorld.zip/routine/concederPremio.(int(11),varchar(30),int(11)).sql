CREATE PROCEDURE concederPremio(IN idRollo INT, IN nombreMaterial VARCHAR(30), IN cantidadAnadida INT)
  BEGIN
	SET @idMaterial = (SELECT ID FROM Materiales WHERE Nombre = nombreMaterial);
	IF EXISTS (SELECT * FROM Rollos_Materiales WHERE ID_Rollo = idRollo AND ID_Material = @idMaterial) THEN
    BEGIN
		START TRANSACTION;
			SET @cantidadOriginal = (SELECT Cantidad FROM Rollos_Materiales  WHERE ID_Rollo = idRollo AND ID_Material = @idMaterial);
            UPDATE Rollos_Materiales SET Cantidad = (@cantidadOriginal + cantidadAnadida) WHERE ID_Rollo = idRollo AND ID_Material = @idMaterial;
        COMMIT;
    END;
    ELSE
    BEGIN
		INSERT INTO Rollos_Materiales(ID_Rollo, ID_Material, Cantidad) VALUE (idRollo, @idMaterial, cantidadAnadida);
    END;
    END IF;
END;
