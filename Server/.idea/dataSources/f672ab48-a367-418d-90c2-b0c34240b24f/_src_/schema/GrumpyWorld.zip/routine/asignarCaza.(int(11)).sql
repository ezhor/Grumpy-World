CREATE PROCEDURE asignarCaza(IN idRollo INT)
  BEGIN
	INSERT INTO Caza (ID_Rollo, ID_Enemigo) VALUE (idRollo, enemigoAleatorio(idRollo));
END;
