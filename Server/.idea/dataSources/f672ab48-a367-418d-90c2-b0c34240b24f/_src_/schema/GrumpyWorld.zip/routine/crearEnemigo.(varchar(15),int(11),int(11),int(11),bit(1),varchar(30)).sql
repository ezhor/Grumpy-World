CREATE PROCEDURE crearEnemigo(IN nNombre VARCHAR(15), IN nFuerza INT, IN nConstitucion INT, IN nDestreza INT,
                              IN nEsJefe BIT, IN nNombreZona VARCHAR(30))
  BEGIN
	INSERT INTO Atributos (Fuerza, Constitucion, Destreza) VALUE (nFuerza, nConstitucion, nDestreza);
    INSERT INTO Enemigos (Nombre, ID_Atributos, ID_Zona, Esjefe)
		SELECT nNombre, LAST_INSERT_ID(), ID, nEsJefe FROM Zonas WHERE Nombre = nNombreZona;
END;
