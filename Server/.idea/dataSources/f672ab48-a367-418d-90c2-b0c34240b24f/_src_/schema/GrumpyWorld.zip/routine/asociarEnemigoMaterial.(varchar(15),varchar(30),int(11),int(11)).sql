CREATE PROCEDURE asociarEnemigoMaterial(IN nombreEnemigo VARCHAR(15), IN nombreMaterial VARCHAR(30),
                                        IN probabilidad  INT, IN cantidad INT)
  BEGIN
	SET @idEnemigo = (SELECT ID FROM Enemigos WHERE Nombre = nombreEnemigo);
    SET @idMaterial = (SELECT ID FROM Materiales WHERE Nombre = nombreMaterial);
    INSERT INTO Enemigos_Materiales (ID_Enemigo, ID_Material, Cantidad, Probabilidad) VALUE (@idEnemigo, @idMaterial, cantidad, probabilidad);
END;
