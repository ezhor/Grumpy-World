CREATE FUNCTION rangoRollo(honorRollo INT, idRollo INT)
  RETURNS INT
  BEGIN
	SET @rango = (SELECT COUNT(*) FROM Rollos WHERE Honor>honorRollo OR (Honor=honorRollo AND ID_Usuario<idRollo) );
    SET @rango = @rango+1;
	RETURN @rango;
END;
