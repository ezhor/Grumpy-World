CREATE PROCEDURE crearUsuario(IN usuario VARCHAR(15), IN contrasena VARCHAR(255), OUT conseguido BIT)
  BEGIN
    INSERT INTO Usuarios (Usuario, Contrasena) VALUE (usuario, contrasena);
    IF(ROW_COUNT()>0) THEN
    BEGIN
		SET @ID_Usuario = LAST_INSERT_ID();
        INSERT INTO Atributos () VALUES ();
        SET @ID_Atributo = LAST_INSERT_ID();
		INSERT INTO Rollos(ID_Usuario, ID_Atributos, ID_Zona) SELECT @ID_Usuario, @ID_Atributo, ID FROM Zonas WHERE Nombre='bano';
        
        SELECT 1 INTO conseguido;
    END;
    END IF;
    
END;
