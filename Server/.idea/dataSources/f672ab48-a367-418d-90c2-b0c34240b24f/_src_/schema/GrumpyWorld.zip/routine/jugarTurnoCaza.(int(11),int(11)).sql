CREATE PROCEDURE jugarTurnoCaza(IN idRollo INT, IN ataqueRollo INT)
  BEGIN
	SET @ataqueEnemigo = ataqueAleatorio();
	SELECT VidaRollo, VidaEnemigo, enemigoMasRapido(AR.Destreza, AE.Destreza) AS enemigoMasRapido, AR.ID AS idAtributosRollo, AE.ID AS idAtributosEnemigo
	  INTO @vidaRollo, @vidaEnemigo, @enemigoMasRapido, @idAtributosRollo, @idAtributosEnemigo
	  FROM Caza AS C
	  INNER JOIN Rollos AS R ON C.ID_Rollo = R.ID_Usuario
	  INNER JOIN Atributos AS AR ON R.ID_Atributos = AR.ID
	  INNER JOIN Enemigos AS E ON C.ID_Enemigo = E.ID
	  INNER JOIN Atributos AS AE ON E.ID_Atributos = AE.ID
	WHERE C.ID_Rollo = idRollo;
    IF(@vidaRollo>0 AND @vidaEnemigo>0) THEN
    BEGIN
		IF(@enemigoMasRapido) THEN
        BEGIN
			SET @vidaRollo = @vidaRollo - dano(@idAtributosEnemigo, @idAtributosRollo, @ataqueEnemigo, ataqueRollo);
            IF(@vidaRollo>0) THEN
            BEGIN
				SET @vidaEnemigo = @vidaEnemigo - dano(@idAtributosRollo, @idAtributosEnemigo, ataqueRollo, @ataqueEnemigo);
            END;
            END IF;
        END;
        ELSE
        BEGIN
			SET @vidaEnemigo = @vidaEnemigo - dano(@idAtributosRollo, @idAtributosEnemigo, ataqueRollo, @ataqueEnemigo);
            IF(@vidaEnemigo>0)THEN
            BEGIN
				SET @vidaRollo = @vidaRollo - dano(@idAtributosEnemigo, @idAtributosRollo, @ataqueEnemigo, ataqueRollo);
            END;
            END IF;
        END;
        END IF;
        
        IF(@vidaRollo<0) THEN
		BEGIN
			SET @vidaRollo = 0;
		END;
		END IF;
        
		IF(@vidaEnemigo<0) THEN
			BEGIN
				SET @vidaEnemigo = 0;
		END;
		END IF;
            
		UPDATE Caza SET VidaRollo = @vidaRollo, VidaEnemigo = @vidaEnemigo, AtaqueRollo = ataqueRollo, AtaqueEnemigo = @ataqueEnemigo WHERE ID_Rollo = idRollo;
    END;
    END IF;
END;
