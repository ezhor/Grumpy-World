CREATE PROCEDURE asociarEquipableMaterial(IN nombreEquipable VARCHAR(30), IN nombreMaterial VARCHAR(30),
                                          IN cantidad        INT)
  BEGIN
	SET @idEquipable = (SELECT ID FROM Equipables WHERE Nombre = nombreEquipable);
    SET @idMaterial = (SELECT ID FROM Materiales WHERE Nombre = nombreMaterial);
    INSERT INTO Equipables_Materiales (ID_Equipable, ID_Material, Cantidad) VALUE (@idEquipable, @idMaterial, cantidad);
END;
