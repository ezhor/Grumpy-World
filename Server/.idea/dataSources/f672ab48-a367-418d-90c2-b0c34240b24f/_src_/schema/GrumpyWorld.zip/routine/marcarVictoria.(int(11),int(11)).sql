CREATE PROCEDURE marcarVictoria(IN idRollo INT, IN idEnemigo INT)
  BEGIN
	IF((SELECT COUNT(*) FROM Vencidos WHERE ID_Rollo = 1 AND ID_Enemigo = 1) = 0) THEN
    BEGIN
		INSERT INTO Vencidos VALUE (ID_Rollo, ID_Enemigo);
    END;
    END IF;
END;
