CREATE PROCEDURE marcarVictoria(IN idRollo INT, IN idEnemigo INT)
  BEGIN
	IF((SELECT COUNT(*) FROM Vencidos WHERE ID_Rollo = idRollo AND ID_Enemigo = idEnemigo) = 0) THEN
    BEGIN
		INSERT INTO Vencidos VALUE (idRollo, idEnemigo);
    END;
    END IF;
END;
