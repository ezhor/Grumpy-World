CREATE FUNCTION dano(idAtributosAtacante INT, idAtributosVictima INT, ataqueAtacante INT, ataqueVictima INT)
  RETURNS INT
  BEGIN
	IF(ataqueAtacante=1) THEN
    BEGIN
		SET @dano = danoBase(idAtributosAtacante, idAtributosVictima);
    END;
    ELSE
    BEGIN
		IF(ataqueAtacante=2) THEN
        BEGIN
			IF(ataqueVictima != 3) THEN
            BEGIN
				SET @dano = 2*danoBase(idAtributosAtacante, idAtributosVictima);
            END;
			ELSE
            BEGIN
				SET @dano = 0;
            END;
            END IF;
        END;
        ELSE
		BEGIN
			-- Por eliminación, el ataque del atacante es 3
            IF(ataqueVictima = 2) THEN
            BEGIN
				/*Si el ataque de la víctima rebota,
                el daño recibido por la víctima va en función de su poder de ataque contra su propio poder de defensa,
                por eso ambos atributos son el ID de la víctima*/
				SET @dano = 2*danoBase(idAtributosVictima, idAtributosVictima);
            END;
            ELSE
            BEGIN
				SET @dano = 0;
            END;
            END IF;
        END;
        END IF;
    END;
    END IF;
    RETURN @dano;
END;
