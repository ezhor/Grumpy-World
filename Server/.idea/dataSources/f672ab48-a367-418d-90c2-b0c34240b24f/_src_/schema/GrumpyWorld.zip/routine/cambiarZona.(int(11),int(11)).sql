CREATE PROCEDURE cambiarZona(IN idRollo INT, IN nombreZona INT)
  BEGIN
	UPDATE Rollos AS R
		SET ID_Zona = (SELECT ID FROM Zonas WHERE Nombre = nombreZona)
		WHERE R.ID_Usuario = idRollo;
END;
