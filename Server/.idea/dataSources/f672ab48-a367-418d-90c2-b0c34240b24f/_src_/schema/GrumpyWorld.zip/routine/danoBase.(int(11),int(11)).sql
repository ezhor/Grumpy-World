CREATE FUNCTION danoBase(idAtributosAtacante INT, idAtributosVictima INT)
  RETURNS INT
  BEGIN
	-- Atributos del atacante
    SELECT Fuerza*(1+Pactos/10), Constitucion*(1+Pactos/10) INTO @fAtacante, @cAtacante FROM Atributos WHERE ID = idAtributosAtacante;
    
    -- Atributos de la víctima
    SELECT Fuerza*(1+Pactos/10), Constitucion*(1+Pactos/10) INTO @fVictima, @cVictima FROM Atributos WHERE ID = idAtributosVictima;
	
    -- Bonus de equipables del atacante
	SELECT
	  IFNULL(
		  (
			SELECT e.Bonus
			FROM Atributos AS A
			  LEFT JOIN Rollos AS R ON A.ID = R.ID_Atributos
			  LEFT JOIN Rollos_Equipables AS RE ON R.ID_Usuario = RE.ID_Rollo
			  LEFT JOIN Equipables AS E ON RE.ID_Equipable = E.ID
			WHERE RE.Equipada AND E.Tipo = 'S' AND A.ID = A2.ID
		  )
		  , 0),
	  IFNULL(
		  (
			SELECT e.Bonus
			FROM Atributos AS A
			  LEFT JOIN Rollos AS R ON A.ID = R.ID_Atributos
			  LEFT JOIN Rollos_Equipables AS RE ON R.ID_Usuario = RE.ID_Rollo
			  LEFT JOIN Equipables AS E ON RE.ID_Equipable = E.ID
			WHERE RE.Equipada AND E.Tipo = 'A' AND A.ID = A2.ID
		  )
		  , 0)
	INTO @bonusSombreroAtacante, @bonusArmaAtacante
	FROM Atributos AS A2
	WHERE A2.ID = idAtributosAtacante;
		  
      -- Bonus de equipables de la víctima
	 SELECT
	  IFNULL(
		  (
			SELECT e.Bonus
			FROM Atributos AS A
			  LEFT JOIN Rollos AS R ON A.ID = R.ID_Atributos
			  LEFT JOIN Rollos_Equipables AS RE ON R.ID_Usuario = RE.ID_Rollo
			  LEFT JOIN Equipables AS E ON RE.ID_Equipable = E.ID
			WHERE RE.Equipada AND E.Tipo = 'S' AND A.ID = A2.ID
		  )
		  , 0),
	  IFNULL(
		  (
			SELECT e.Bonus
			FROM Atributos AS A
			  LEFT JOIN Rollos AS R ON A.ID = R.ID_Atributos
			  LEFT JOIN Rollos_Equipables AS RE ON R.ID_Usuario = RE.ID_Rollo
			  LEFT JOIN Equipables AS E ON RE.ID_Equipable = E.ID
			WHERE RE.Equipada AND E.Tipo = 'A' AND A.ID = A2.ID
		  )
		  , 0)
	INTO @bonusSombreroVictima, @bonusArmaVictima
	FROM Atributos AS A2
	WHERE A2.ID = idAtributosVictima;
    
    -- Fórmula: Daño = 10*(FuerzaAtacante + BonusArmaAtacante) / (ConstituciónVíctima + BonusSombreroVíctima)
    -- Hasta un 15% de este daño se puede reducir de forma aleatoria
    SET @dano = 10*(0.85*((@fAtacante+@bonusArmaAtacante)/(@cVictima+@bonusSombreroVictima))) + (RAND()*0.15*((@fAtacante+@bonusArmaAtacante)/(@cVictima+@bonusSombreroVictima)));
    RETURN @dano;
  END;
