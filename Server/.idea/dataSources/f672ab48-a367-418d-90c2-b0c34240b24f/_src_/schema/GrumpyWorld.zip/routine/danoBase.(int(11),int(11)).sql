CREATE FUNCTION danoBase(idAtributosAtacante INT, idAtributosVictima INT)
  RETURNS INT
  BEGIN
    SELECT Fuerza, Constitucion, Destreza, Pactos INTO @fAtacante, @cAtacante, @dAtacante, @pAtacante FROM Atributos WHERE ID = idAtributosAtacante;
    SELECT Fuerza, Constitucion, Destreza, Pactos INTO @fVictima, @cVictima, @dVictima, @pVictima FROM Atributos WHERE ID = idAtributosVictima;
    SET @dano = (0.85*@fAtacante/@cVictima) + (RAND()*0.15*@fAtacante/@cVictima);
    RETURN @dano;
  END;
