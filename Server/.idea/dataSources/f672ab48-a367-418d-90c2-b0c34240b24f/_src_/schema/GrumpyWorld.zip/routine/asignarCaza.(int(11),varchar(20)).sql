CREATE PROCEDURE asignarCaza(IN idRollo INT, IN nombreEnemigo VARCHAR(20))
  BEGIN
	INSERT INTO Caza (ID_Rollo, ID_Enemigo)
		SELECT idRollo, ID FROM Enemigos WHERE Enemigos.Nombre = nombreEnemigo;
END;
