CREATE FUNCTION rangoRollo(honor INT)
  RETURNS INT
  BEGIN
	SET @rango = (SELECT COUNT(*) FROM Rollos WHERE Honor>0);
    SET @rango = @rango+1;
	RETURN @rango;
END;
