create function enemigoAleatorio(idRollo int)
  returns int
  BEGIN
    DECLARE _enemigosVencidos, _idEnemigo INT;

    SET _enemigosVencidos = (
      SELECT COUNT(*)
      FROM Rollos AS R
        INNER JOIN Vencidos AS V
          ON R.ID_Usuario = V.ID_Rollo
        INNER JOIN Enemigos AS E
          ON V.ID_Enemigo = E.ID
      WHERE R.ID_Usuario = idRollo AND
            R.ID_Zona = E.ID_Zona
    );
    IF(_enemigosVencidos >= 4) THEN
      BEGIN
        SET _idEnemigo = (SELECT E.ID
                          FROM Rollos AS R
                            INNER JOIN Zonas AS Z
                              ON R.ID_Zona = Z.ID
                            INNER JOIN Enemigos AS E
                              ON Z.ID = E.ID_Zona
                          WHERE R.ID_Usuario = idRollo
                          ORDER BY RAND()
                          LIMIT 1);
      END;
    ELSE
      SET _idEnemigo = (SELECT E.ID
                        FROM Rollos AS R
                          INNER JOIN Zonas AS Z
                            ON R.ID_Zona = Z.ID
                          INNER JOIN Enemigos AS E
                            ON Z.ID = E.ID_Zona
                        WHERE R.ID_Usuario = idRollo AND
                              E.EsJefe = 0
                        ORDER BY RAND()
                        LIMIT 1);
      BEGIN
      END;
    END IF;
    RETURN _idEnemigo;
  END;

