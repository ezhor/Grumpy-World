create procedure borrarAmigo(IN idUsuario int, IN idAmigo int)
  BEGIN
    DELETE FROM Amigos WHERE (ID_Usuario1 = idUsuario AND ID_Usuario2 = idAmigo) OR (ID_Usuario1 = idAmigo AND ID_Usuario2 = idUsuario);
  END;

