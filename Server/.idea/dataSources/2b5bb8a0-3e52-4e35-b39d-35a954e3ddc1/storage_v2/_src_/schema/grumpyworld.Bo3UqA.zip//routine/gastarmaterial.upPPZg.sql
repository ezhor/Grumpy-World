create procedure gastarMaterial(IN idRollo int, IN idMaterial int, IN cantidadGastada int)
  BEGIN
    DECLARE _cantidadOriginal INT;

    START TRANSACTION;
    SET _cantidadOriginal = (SELECT Cantidad FROM Rollos_Materiales  WHERE ID_Rollo = idRollo AND ID_Material = idMaterial);
    UPDATE Rollos_Materiales SET Cantidad = (_cantidadOriginal - cantidadGastada) WHERE ID_Rollo = idRollo AND ID_Material = idMaterial;
    COMMIT;
  END;

