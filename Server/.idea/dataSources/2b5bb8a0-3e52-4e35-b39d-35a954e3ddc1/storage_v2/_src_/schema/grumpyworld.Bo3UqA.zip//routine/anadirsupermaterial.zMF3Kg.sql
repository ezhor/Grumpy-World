create procedure anadirSupermaterial(IN idRollo int, IN idMaterial int)
  BEGIN
    DECLARE _nombreMaterial VARCHAR(30);

    SET _nombreMaterial = (SELECT Nombre FROM Materiales WHERE ID = idMaterial);
    CALL concederPremio(idRollo, _nombreMaterial, 1);
  END;

