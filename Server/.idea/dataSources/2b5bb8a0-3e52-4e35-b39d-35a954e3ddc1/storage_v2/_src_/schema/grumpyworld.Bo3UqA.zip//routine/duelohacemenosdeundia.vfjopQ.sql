create function dueloHaceMenosDeUnDia(idRollo int, idOponente int)
  returns bit
  BEGIN
    RETURN EXISTS(SELECT 1
                  FROM Ultimos_Duelos
                  WHERE ID_Rollo = idRollo AND ID_Oponente = idOponente AND
                        Momento > UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 day)));
  END;

