create procedure entrenar(IN idUsuario int, IN atributo varchar(15))
  BEGIN
    IF (atributo = 'fuerza') THEN
      BEGIN
        UPDATE Atributos
          INNER JOIN Rollos
            ON Atributos.ID = Rollos.ID_Atributos
        SET Atributos.FinEntrenamiento = UNIX_TIMESTAMP()+((Atributos.Fuerza)*(Atributos.Fuerza)),
          Atributos.Fuerza = Atributos.Fuerza+1
        WHERE Rollos.ID_Usuario = idUsuario;

      END;
    ELSE IF (atributo = 'constitucion') THEN
      BEGIN
        UPDATE Atributos
          INNER JOIN Rollos
            ON Atributos.ID = Rollos.ID_Atributos
        SET Atributos.FinEntrenamiento = UNIX_TIMESTAMP()+((Atributos.Constitucion)*(Atributos.Constitucion)),
          Atributos.Constitucion = Atributos.Constitucion+1
        WHERE Rollos.ID_Usuario = idUsuario;

      END;
    ELSE IF (atributo = 'destreza') THEN
      BEGIN
        UPDATE Atributos
          INNER JOIN Rollos
            ON Atributos.ID = Rollos.ID_Atributos
        SET Atributos.FinEntrenamiento = UNIX_TIMESTAMP()+((Atributos.Destreza)*(Atributos.Destreza)),
          Atributos.Destreza = Atributos.Destreza+1
        WHERE Rollos.ID_Usuario = idUsuario;

      END;
    END IF;
    END IF;
    END IF;
  END;

