create procedure crearEnemigo(IN nNombre varchar(15), IN nFuerza int, IN nConstitucion int, IN nDestreza int,
                              IN nEsJefe bit, IN nNombreZona varchar(30))
  BEGIN
    INSERT INTO Atributos (Fuerza, Constitucion, Destreza) VALUE (nFuerza, nConstitucion, nDestreza);
    INSERT INTO Enemigos (Nombre, ID_Atributos, ID_Zona, Esjefe)
      SELECT nNombre, LAST_INSERT_ID(), ID, nEsJefe FROM Zonas WHERE Nombre = nNombreZona;
  END;

