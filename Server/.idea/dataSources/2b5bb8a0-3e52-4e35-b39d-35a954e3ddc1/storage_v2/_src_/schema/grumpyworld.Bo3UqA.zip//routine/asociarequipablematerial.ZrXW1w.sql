create procedure asociarEquipableMaterial(IN nombreEquipable varchar(30), IN nombreMaterial varchar(30),
                                          IN `_cantidad`     int)
  BEGIN
    DECLARE _idEquipable, _idMaterial INT;

    SET _idEquipable = (SELECT ID FROM Equipables WHERE Nombre = nombreEquipable);
    SET _idMaterial = (SELECT ID FROM Materiales WHERE Nombre = nombreMaterial);
    INSERT INTO Equipables_Materiales (ID_Equipable, ID_Material, Cantidad) VALUE (_idEquipable, _idMaterial, _cantidad);
  END;

