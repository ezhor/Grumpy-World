create function existeUsuario(nombre_usuario varchar(15))
  returns bit
  BEGIN
    RETURN (SELECT COUNT(*) FROM Usuarios WHERE Usuario = nombre_usuario)>0;
  END;

