create procedure marcarUltimoDuelo(IN `_idRollo` int, IN `_idOponente` int)
  BEGIN
	START TRANSACTION;
	IF EXISTS (SELECT 1 FROM Ultimos_Duelos WHERE ID_Rollo = _idRollo AND ID_Oponente = _idOponente) THEN
      BEGIN
        UPDATE Ultimos_Duelos SET Momento = UNIX_TIMESTAMP() WHERE ID_Rollo = _idRollo AND ID_Oponente = _idOponente;
      END;
    ELSE
      BEGIN
        INSERT INTO Ultimos_Duelos(ID_Rollo, ID_Oponente, Momento) VALUE (_idRollo, _idMaterial, UNIX_TIMESTAMP());
      END;
    END IF;
    COMMIT;
  END;

