create procedure revisarNivel(IN idRollo int)
  BEGIN
    DECLARE _nivel INT;

    SET _nivel = (SELECT COUNT(*)+1
                  FROM Rollos AS R
                    INNER JOIN Vencidos AS V
                      ON R.ID_Usuario = V.ID_Rollo
                    INNER JOIN Enemigos AS E
                      ON V.ID_Enemigo = E.ID
                  WHERE R.ID_Usuario = idRollo AND E.EsJefe);

    UPDATE Rollos AS R SET Nivel = _nivel
    WHERE R.ID_Usuario = idRollo;
  END;

