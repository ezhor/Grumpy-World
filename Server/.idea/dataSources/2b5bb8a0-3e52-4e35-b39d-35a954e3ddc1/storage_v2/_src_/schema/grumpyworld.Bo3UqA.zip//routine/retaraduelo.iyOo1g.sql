create procedure retarADuelo(IN idRollo int, IN idOponente int)
  BEGIN
	DECLARE _previamenteRetado BIT;
    DECLARE _momento INT;
    
	START TRANSACTION;
	DELETE FROM Duelos WHERE ID_Rollo = idRollo;
    IF (EXISTS(SELECT 1 FROM Duelos WHERE ID_Rollo = idOponente AND ID_Oponente = idRollo)) THEN
    BEGIN
		SET _momento = UNIX_TIMESTAMP();
        UPDATE Duelos SET Momento = _momento WHERE ID_Rollo = idOponente AND ID_Oponente = idRollo;
		INSERT INTO Duelos (ID_Rollo, ID_Oponente, Turno, Vida, Ataque, Momento) VALUE (idRollo, idOponente, 0, NULL, NULL, _momento);
    END;
    ELSE
    BEGIN
		INSERT INTO Duelos (ID_Rollo, ID_Oponente, Turno, Vida, Ataque, Momento) VALUE (idRollo, idOponente, 0, NULL, NULL, NULL);
    END;
    END IF;
    
    
    COMMIT;
  END;

