create procedure retarADuelo(IN idRollo int, IN idOponente int)
  BEGIN
    INSERT INTO Duelos (ID_Rollo, ID_Oponente, Turno, Vida, Ataque, Momento) VALUE (idRollo, idOponente, 0, NULL, NULL, NULL);
  END;

