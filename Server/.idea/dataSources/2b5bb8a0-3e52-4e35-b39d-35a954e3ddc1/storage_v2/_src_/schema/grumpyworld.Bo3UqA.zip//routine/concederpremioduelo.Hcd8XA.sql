create procedure concederPremioDuelo(IN `_idRollo` int, IN `_cantidad` int)
  BEGIN
	DELETE FROM Duelos WHERE ID_Rollo = _idRollo;
    UPDATE Rollos SET Honor = Honor + _cantidad WHERE ID_Usuario = _idRollo;
  END;

