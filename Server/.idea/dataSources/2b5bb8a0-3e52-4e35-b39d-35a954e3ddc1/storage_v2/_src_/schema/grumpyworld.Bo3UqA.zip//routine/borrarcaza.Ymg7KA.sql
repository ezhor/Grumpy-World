create procedure borrarCaza(IN idRollo int)
  BEGIN
    DELETE FROM Caza WHERE ID_Rollo = idRollo;
  END;

