create procedure marcarVictoria(IN idRollo int, IN idEnemigo int)
  BEGIN
    IF((SELECT COUNT(*) FROM Vencidos WHERE ID_Rollo = idRollo AND ID_Enemigo = idEnemigo) = 0) THEN
      BEGIN
        INSERT INTO Vencidos VALUE (idRollo, idEnemigo);
      END;
    END IF;
  END;

