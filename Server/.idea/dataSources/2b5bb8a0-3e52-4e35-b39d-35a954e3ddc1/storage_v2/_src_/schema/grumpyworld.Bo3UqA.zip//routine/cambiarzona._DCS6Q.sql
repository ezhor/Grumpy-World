create procedure cambiarZona(IN idRollo int, IN nombreZona varchar(15))
  BEGIN
    CALL borrarCaza(idRollo);
    UPDATE Rollos AS R
    SET ID_Zona = (SELECT ID FROM Zonas WHERE Nombre = nombreZona)
    WHERE R.ID_Usuario = idRollo;
  END;

