create function rangoRollo(honorRollo int, idRollo int)
  returns int
  BEGIN
    DECLARE _rango INT;

    SET _rango = (SELECT COUNT(*) FROM Rollos WHERE Honor>honorRollo OR (Honor=honorRollo AND ID_Usuario<idRollo) );
    SET _rango = _rango+1;
    RETURN _rango;
  END;

