create procedure crearUsuario(IN `_usuario` varchar(15), IN `_contrasena` varchar(255), OUT conseguido bit)
  BEGIN
    DECLARE _idUsuario, _idAtributos INT;

    INSERT INTO Usuarios (Usuario, Contrasena) VALUE (_usuario, _contrasena);
    IF(ROW_COUNT()>0) THEN
      BEGIN
        SET _idUsuario = LAST_INSERT_ID();
        INSERT INTO Atributos () VALUES ();
        SET _idAtributos = LAST_INSERT_ID();
        INSERT INTO Rollos(ID_Usuario, ID_Atributos, ID_Zona) SELECT _idUsuario, _idAtributos, ID FROM Zonas WHERE Nombre='bano';

        SELECT 1 INTO conseguido;
      END;
    END IF;

  END;

