create function calcularPremioDuelo(idRollo int)
  returns int
  BEGIN
	DECLARE premio, vidaRollo, fuerzaRollo, constitucionRollo, destrezaRollo, pactosRollo, vidaOponente, fuerzaOponente, constitucionOponente, destrezaOponente, pactosOponente INT;
    DECLARE oponenteHaBorradoSusDatos BIT;
    
	SET premio = 0;
	SET oponenteHaBorradoSusDatos = (SELECT NOT EXISTS(SELECT 1
									  FROM Duelos AS D1
										INNER JOIN Duelos AS D2
										  ON D1.ID_Rollo = D2.ID_Oponente AND D1.Turno = D2.Turno
									  WHERE D1.ID_Rollo = idRollo
									  ORDER BY D1.Turno DESC
									  LIMIT 1));   
                                      
	IF(oponenteHaBorradoSusDatos) THEN
    BEGIN
		SELECT D1.Vida, A1.Fuerza, A1.Constitucion, A1.Destreza, A1.Pactos, A2.Fuerza, A2.Constitucion, A2.Destreza, A2.Pactos
			INTO vidaRollo, fuerzaRollo, constitucionRollo, destrezaRollo, pactosRollo, fuerzaOponente, constitucionOponente, destrezaOponente, pactosOponente
			FROM Duelos AS D1
			  INNER JOIN Rollos AS R1
				ON D1.ID_Rollo = R1.ID_Usuario
			  INNER JOIN Atributos AS A1
				ON R1.ID_Atributos = A1.ID
			  INNER JOIN Rollos AS R2
				ON D1.ID_Oponente = R2.ID_Usuario
			  INNER JOIN Atributos AS A2
				ON R2.ID_Atributos = A2.ID
			WHERE D1.ID_Rollo = idRollo
			ORDER BY D1.Turno DESC
			LIMIT 1;
            
            IF(vidaRollo IS NOT NULL) THEN
            BEGIN
				IF(vidaRollo > 0) THEN
				BEGIN
					SET premio = 10 * ( (fuerzaOponente + constitucionOponente + destrezaOponente) * (1+(pactosOponente/10)) )/( (fuerzaRollo + constitucionRollo + destrezaRollo) * (1+(pactosRollo)));
				END;
				ELSE
					SET premio = 1;
				BEGIN
				END;
				END IF;
			END;
            END IF;			
    END;    
    ELSE
    BEGIN
		SELECT D1.Vida, A1.Fuerza, A1.Constitucion, A1.Destreza, A1.Pactos, D2.Vida, A2.Fuerza, A2.Constitucion, A2.Destreza, A2.Pactos
			INTO vidaRollo, fuerzaRollo, constitucionRollo, destrezaRollo, pactosRollo, vidaOponente, fuerzaOponente, constitucionOponente, destrezaOponente, pactosOponente
			FROM Duelos AS D1
			  INNER JOIN Duelos AS D2
				ON D1.ID_Rollo = D2.ID_Oponente AND D1.Turno = D2.Turno
			  INNER JOIN Rollos AS R1
				ON D1.ID_Rollo = R1.ID_Usuario
			  INNER JOIN Rollos AS R2
				ON D2.ID_Rollo = R2.ID_Usuario
			  INNER JOIN Atributos AS A1
				ON R1.ID_Atributos = A1.ID
			  INNER JOIN Atributos AS A2
				ON R2.ID_Atributos = A2.ID
			WHERE D1.ID_Rollo = idRollo
			ORDER BY D1.Turno DESC
			LIMIT 1;
            
		IF(vidaRollo = 0 OR vidaOponente = 0)THEN
        BEGIN
			IF(vidaRollo >0)THEN
            BEGIN
				SET premio = 10 * ( (fuerzaOponente + constitucionOponente + destrezaOponente) * (1+(pactosOponente/10)) )/( (fuerzaRollo + constitucionRollo + destrezaRollo) * (1+(pactosRollo)));
            END;
            ELSE
            BEGIN
				SET premio = 1;
            END;
            END IF;
        END;
        END IF;
    END;
    END IF;
       
    RETURN premio;
END;

