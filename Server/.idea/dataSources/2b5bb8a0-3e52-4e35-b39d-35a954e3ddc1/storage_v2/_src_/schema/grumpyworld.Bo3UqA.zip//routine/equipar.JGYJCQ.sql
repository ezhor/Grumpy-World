create procedure equipar(IN idRollo int, IN idEquipable int)
  BEGIN
    DECLARE _tipoEquipable CHAR(1);

    START TRANSACTION;
    SET _tipoEquipable = (SELECT Tipo FROM Equipables WHERE ID = idEquipable);
    UPDATE Rollos_Equipables AS RE INNER JOIN Equipables AS E ON RE.ID_Equipable = E.ID SET Equipado = 0 WHERE RE.ID_Rollo = idRollo AND E.Tipo = _tipoEquipable;
    UPDATE Rollos_Equipables SET Equipado = 1 WHERE ID_Rollo = idRollo AND ID_Equipable = idEquipable;
    COMMIT;
  END;

