create function oponenteHaElegidoSiguienteTurno(idRollo int)
  returns bit
  BEGIN
    DECLARE _idOponente, _turno INT;

    SELECT ID_Oponente, Turno
    INTO _idOponente, _turno
    FROM Duelos
    WHERE ID_Rollo = idRollo
    ORDER BY Turno DESC
    LIMIT 1;

    RETURN EXISTS(SELECT 1
                  FROM Duelos
                  WHERE ID_Rollo = _idOponente AND ID_Oponente = idRollo AND Turno = (_turno+1));
  END;

