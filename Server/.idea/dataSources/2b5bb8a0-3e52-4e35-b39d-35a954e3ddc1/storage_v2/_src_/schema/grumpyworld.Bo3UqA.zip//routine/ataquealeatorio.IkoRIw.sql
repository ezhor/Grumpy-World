create function ataqueAleatorio()
  returns int
  BEGIN
    RETURN FLOOR(1 + (RAND() * 3));
  END;

