create procedure concederPremio(IN idRollo int, IN nombreMaterial varchar(30), IN cantidadAnadida int)
  BEGIN
    DECLARE _idMaterial, _cantidadOriginal INT;

    SET _idMaterial = (SELECT ID FROM Materiales WHERE Nombre = nombreMaterial);
    IF EXISTS (SELECT 1 FROM Rollos_Materiales WHERE ID_Rollo = idRollo AND ID_Material = _idMaterial) THEN
      BEGIN
        START TRANSACTION;
        SET _cantidadOriginal = (SELECT Cantidad FROM Rollos_Materiales  WHERE ID_Rollo = idRollo AND ID_Material = _idMaterial);
        UPDATE Rollos_Materiales SET Cantidad = (_cantidadOriginal + cantidadAnadida) WHERE ID_Rollo = idRollo AND ID_Material = _idMaterial;
        COMMIT;
      END;
    ELSE
      BEGIN
        INSERT INTO Rollos_Materiales(ID_Rollo, ID_Material, Cantidad) VALUE (idRollo, _idMaterial, cantidadAnadida);
      END;
    END IF;
  END;

