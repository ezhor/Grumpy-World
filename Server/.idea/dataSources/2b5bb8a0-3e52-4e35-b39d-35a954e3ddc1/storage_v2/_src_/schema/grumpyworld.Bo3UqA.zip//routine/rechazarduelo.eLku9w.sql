create procedure rechazarDuelo(IN idRollo int, IN idOponente int)
  BEGIN
    DELETE FROM Duelos WHERE ((ID_Rollo = idRollo AND ID_Oponente = idOponente) OR (ID_Oponente = idRollo AND ID_Rollo = idOponente)) AND Turno = 0;
  END;

