create function danoBase(idAtributosAtacante int, idAtributosVictima int)
  returns int
  BEGIN
    DECLARE _fAtacante, _cAtacante, _fVictima, _cVictima, _bonusSombreroAtacante, _bonusArmaAtacante, _bonusSombreroVictima, _bonusArmaVictima, _dano INT;

    -- Atributos del atacante
    SELECT Fuerza*(1+(Pactos/10)), Constitucion*(1+(Pactos/10)) INTO _fAtacante, _cAtacante FROM Atributos WHERE ID = idAtributosAtacante;

    -- Atributos de la víctima
    SELECT Fuerza*(1+(Pactos/10)), Constitucion*(1+(Pactos/10)) INTO _fVictima, _cVictima FROM Atributos WHERE ID = idAtributosVictima;

    -- Bonus de equipables del atacante
    SELECT
      IFNULL(
          (
            SELECT E.Bonus
            FROM Atributos AS A
              LEFT JOIN Rollos AS R ON A.ID = R.ID_Atributos
              LEFT JOIN Rollos_Equipables AS RE ON R.ID_Usuario = RE.ID_Rollo
              LEFT JOIN Equipables AS E ON RE.ID_Equipable = E.ID
            WHERE RE.Equipado AND E.Tipo = 'S' AND A.ID = A2.ID
          )
          , 0),
      IFNULL(
          (
            SELECT E.Bonus
            FROM Atributos AS A
              LEFT JOIN Rollos AS R ON A.ID = R.ID_Atributos
              LEFT JOIN Rollos_Equipables AS RE ON R.ID_Usuario = RE.ID_Rollo
              LEFT JOIN Equipables AS E ON RE.ID_Equipable = E.ID
            WHERE RE.Equipado AND E.Tipo = 'A' AND A.ID = A2.ID
          )
          , 0)
    INTO _bonusSombreroAtacante, _bonusArmaAtacante
    FROM Atributos AS A2
    WHERE A2.ID = idAtributosAtacante;

    -- Bonus de equipables de la víctima
    SELECT
      IFNULL(
          (
            SELECT E.Bonus
            FROM Atributos AS A
              LEFT JOIN Rollos AS R ON A.ID = R.ID_Atributos
              LEFT JOIN Rollos_Equipables AS RE ON R.ID_Usuario = RE.ID_Rollo
              LEFT JOIN Equipables AS E ON RE.ID_Equipable = E.ID
            WHERE RE.Equipado AND E.Tipo = 'S' AND A.ID = A2.ID
          )
          , 0),
      IFNULL(
          (
            SELECT E.Bonus
            FROM Atributos AS A
              LEFT JOIN Rollos AS R ON A.ID = R.ID_Atributos
              LEFT JOIN Rollos_Equipables AS RE ON R.ID_Usuario = RE.ID_Rollo
              LEFT JOIN Equipables AS E ON RE.ID_Equipable = E.ID
            WHERE RE.Equipado AND E.Tipo = 'A' AND A.ID = A2.ID
          )
          , 0)
    INTO _bonusSombreroVictima, _bonusArmaVictima
    FROM Atributos AS A2
    WHERE A2.ID = idAtributosVictima;

    SET _dano = 10*(0.85*((_fAtacante+_bonusArmaAtacante)/(_cVictima+_bonusSombreroVictima))) + (RAND()*0.15*((_fAtacante+_bonusArmaAtacante)/(_cVictima+_bonusSombreroVictima)));
    RETURN _dano;
  END;

