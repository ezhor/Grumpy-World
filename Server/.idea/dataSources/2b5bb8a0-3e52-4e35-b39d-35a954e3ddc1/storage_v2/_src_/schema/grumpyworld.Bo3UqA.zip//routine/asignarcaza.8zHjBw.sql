create procedure asignarCaza(IN idRollo int)
  BEGIN
    INSERT INTO Caza (ID_Rollo, ID_Enemigo) VALUE (idRollo, enemigoAleatorio(idRollo));
  END;

