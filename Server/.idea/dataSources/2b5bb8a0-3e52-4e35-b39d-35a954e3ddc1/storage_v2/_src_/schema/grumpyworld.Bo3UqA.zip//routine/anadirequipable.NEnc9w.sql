create procedure anadirEquipable(IN idRollo int, IN idEquipable int)
  BEGIN
    INSERT INTO Rollos_Equipables (ID_Rollo, ID_Equipable, Equipado) VALUES (idRollo, idEquipable, 0);
  END;

