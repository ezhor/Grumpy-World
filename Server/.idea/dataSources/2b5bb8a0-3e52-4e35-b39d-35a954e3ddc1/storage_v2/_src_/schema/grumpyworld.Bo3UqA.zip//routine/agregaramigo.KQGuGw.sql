create procedure agregarAmigo(IN idUsuario int, IN idAmigo int)
  BEGIN
    INSERT INTO Amigos (ID_Usuario1, ID_Usuario2) VALUES (idUsuario, idAmigo);
  END;

