create function enemigoMasRapido(destrezaRollo int, destrezaEnemigo int)
  returns bit
  BEGIN
    RETURN destrezaEnemigo>destrezaRollo;
  END;

