create procedure elegirTurnoDuelo(IN idRollo int, IN ataqueRollo int)
  BEGIN
    DECLARE _idOponente, _turno INT;

    SELECT ID_Oponente, Turno
    INTO _idOponente, _turno
    FROM Duelos WHERE ID_Rollo = idRollo
    ORDER BY Turno DESC
    LIMIT 1;
    INSERT INTO Duelos (ID_Rollo, ID_Oponente, Turno, Vida, Ataque, Momento) VALUE (idRollo, _idOponente, (_turno+1), NULL, ataqueRollo, NULL);
  END;

