create procedure jugarTurnoCaza(IN idRollo int, IN ataqueRollo int)
  BEGIN
    DECLARE _ataqueEnemigo, _vidaRollo, _vidaEnemigo, _enemigoMasRapido, _idAtributosRollo, _idAtributosEnemigo, _idEnemigo INT;

    SET _ataqueEnemigo = ataqueAleatorio();
    SELECT VidaRollo, VidaEnemigo, enemigoMasRapido(AR.Destreza, AE.Destreza) AS enemigoMasRapido, AR.ID AS idAtributosRollo, AE.ID AS idAtributosEnemigo, E.ID
    INTO _vidaRollo, _vidaEnemigo, _enemigoMasRapido, _idAtributosRollo, _idAtributosEnemigo, _idEnemigo
    FROM Caza AS C
      INNER JOIN Rollos AS R ON C.ID_Rollo = R.ID_Usuario
      INNER JOIN Atributos AS AR ON R.ID_Atributos = AR.ID
      INNER JOIN Enemigos AS E ON C.ID_Enemigo = E.ID
      INNER JOIN Atributos AS AE ON E.ID_Atributos = AE.ID
    WHERE C.ID_Rollo = idRollo;
    IF(_vidaRollo>0 AND _vidaEnemigo>0) THEN
      BEGIN
        IF(_enemigoMasRapido) THEN
          BEGIN
            SET _vidaRollo = _vidaRollo - dano(_idAtributosEnemigo, _idAtributosRollo, _ataqueEnemigo, ataqueRollo);
            IF(_vidaRollo>0) THEN
              BEGIN
                SET _vidaEnemigo = _vidaEnemigo - dano(_idAtributosRollo, _idAtributosEnemigo, ataqueRollo, _ataqueEnemigo);
              END;
            END IF;
          END;
        ELSE
          BEGIN
            SET _vidaEnemigo = _vidaEnemigo - dano(_idAtributosRollo, _idAtributosEnemigo, ataqueRollo, _ataqueEnemigo);
            IF(_vidaEnemigo>0)THEN
              BEGIN
                SET _vidaRollo = _vidaRollo - dano(_idAtributosEnemigo, _idAtributosRollo, _ataqueEnemigo, ataqueRollo);
              END;
            END IF;
          END;
        END IF;

        IF(_vidaRollo<0) THEN
          BEGIN
            SET _vidaRollo = 0;
          END;
        END IF;

        IF(_vidaEnemigo<0) THEN
          BEGIN
            SET _vidaEnemigo = 0;
          END;
        END IF;

        IF(_vidaRollo>0 AND _vidaEnemigo = 0) THEN
          BEGIN
            CALL marcarVictoria(idRollo, _idEnemigo);
            CALL revisarNivel(idRollo);
          END;
        END IF;

        UPDATE Caza SET VidaRollo = _vidaRollo, VidaEnemigo = _vidaEnemigo, AtaqueRollo = ataqueRollo, AtaqueEnemigo = _ataqueEnemigo WHERE ID_Rollo = idRollo;
      END;
    END IF;
  END;

