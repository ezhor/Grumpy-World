create procedure jugarTurnoDuelo(IN idRollo int, IN ataqueRollo int)
  BEGIN
    DECLARE _vidaRollo, _enemigoMasRapido, _idAtributosRollo, _idAtributosEnemigo, _idEnemigo, _turno, _ataqueEnemigo, _vidaEnemigo, _habiaElegidoAtaque, _momento INT;

    SELECT D1.Vida, enemigoMasRapido(A1.Destreza, A2.Destreza), A1.ID, A2.ID, D1.ID_Oponente, D1.Turno
    INTO _vidaRollo, _enemigoMasRapido, _idAtributosRollo, _idAtributosEnemigo, _idEnemigo, _turno
    FROM Duelos AS D1
      INNER JOIN Rollos AS R1
        ON D1.ID_Rollo = R1.ID_Usuario
      INNER JOIN Atributos AS A1
        ON R1.ID_Atributos = A1.ID
      INNER JOIN Rollos AS R2
        ON D1.ID_Oponente = R2.ID_Usuario
      INNER JOIN Atributos AS A2
        ON R2.ID_Atributos = A2.ID
    WHERE D1.ID_Rollo = idRollo
    ORDER BY D1.Turno DESC
    LIMIT 1;

    SET _ataqueEnemigo = (SELECT Ataque FROM Duelos WHERE ID_Oponente = idRollo ORDER BY Turno DESC LIMIT 1);
    SET _vidaEnemigo = (SELECT Vida FROM Duelos WHERE ID_Oponente = idRollo AND Turno = _turno LIMIT 1);

    SET _habiaElegidoAtaque = TRUE;
    IF(_ataqueEnemigo IS NULL) THEN
      BEGIN
        SET _habiaElegidoAtaque = FALSE;
        SET _ataqueEnemigo = ataqueAleatorio();
      END;
    END IF;

    IF(_enemigoMasRapido) THEN
      BEGIN
        SET _vidaRollo = _vidaRollo - dano(_idAtributosEnemigo, _idAtributosRollo, _ataqueEnemigo, ataqueRollo);
        IF(_vidaRollo>0) THEN
          BEGIN
            SET _vidaEnemigo = _vidaEnemigo - dano(_idAtributosRollo, _idAtributosEnemigo, ataqueRollo, _ataqueEnemigo);
          END;
        END IF;
      END;
    ELSE
      BEGIN
        SET _vidaEnemigo = _vidaEnemigo - dano(_idAtributosRollo, _idAtributosEnemigo, ataqueRollo, _ataqueEnemigo);
        IF(_vidaEnemigo>0)THEN
          BEGIN
            SET _vidaRollo = _vidaRollo - dano(_idAtributosEnemigo, _idAtributosRollo, _ataqueEnemigo, ataqueRollo);
          END;
        END IF;
      END;
    END IF;

    IF(_vidaRollo<0) THEN
      BEGIN
        SET _vidaRollo = 0;
      END;
    END IF;

    IF(_vidaEnemigo<0) THEN
      BEGIN
        SET _vidaEnemigo = 0;
      END;
    END IF;

    IF(_vidaRollo>0 AND _vidaEnemigo = 0) THEN
      BEGIN
        -- IF vacío para posible condición de victoria
        -- CALL marcarVictoria(idRollo, _idEnemigo);
        -- CALL revisarNivel(idRollo);
      END;
    END IF;

    SET _momento = UNIX_TIMESTAMP();

    IF(_habiaElegidoAtaque) THEN
      BEGIN
        INSERT INTO Duelos (ID_Rollo, ID_Oponente, Turno, Vida, Ataque, Momento) VALUE (idRollo, _idEnemigo, (_turno+1), _vidaRollo, ataqueRollo, _momento);
        UPDATE Duelos SET Vida = _vidaEnemigo, Momento = _momento WHERE ID_Rollo = _idEnemigo AND ID_Oponente = idRollo AND Turno = (_turno+1);
      END;
    ELSE
      BEGIN
        INSERT INTO Duelos (ID_Rollo, ID_Oponente, Turno, Vida, Ataque, Momento) VALUES
          (idRollo, _idEnemigo, (_turno+1), _vidaRollo, ataqueRollo, _momento),
          (_idEnemigo, idRollo, (_turno+1), _vidaEnemigo, _ataqueEnemigo, _momento);
      END;
    END IF;
  END;

