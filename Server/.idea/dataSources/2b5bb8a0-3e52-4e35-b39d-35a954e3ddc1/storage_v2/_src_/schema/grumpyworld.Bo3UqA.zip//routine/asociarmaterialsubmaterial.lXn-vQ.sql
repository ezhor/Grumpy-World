create procedure asociarMaterialSubmaterial(IN nombreMaterial varchar(30), IN nombreSubmaterial varchar(30),
                                            IN `_cantidad`    int)
  BEGIN
    DECLARE _idMaterial, _idSubmaterial INT;

    SET _idMaterial = (SELECT ID FROM Materiales WHERE Nombre = nombreMaterial);
    SET _idSubmaterial = (SELECT ID FROM Materiales WHERE Nombre = nombreSubmaterial);
    INSERT INTO Materiales_Materiales (ID_Material, ID_Submaterial, Cantidad) VALUE (_idMaterial, _idSubmaterial, _cantidad);
  END;

