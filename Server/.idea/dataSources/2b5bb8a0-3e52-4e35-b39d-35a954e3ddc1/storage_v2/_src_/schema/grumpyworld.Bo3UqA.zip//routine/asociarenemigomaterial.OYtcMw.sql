create procedure asociarEnemigoMaterial(IN nombreEnemigo   varchar(15), IN nombreMaterial varchar(30),
                                        IN `_cantidad`     int, IN `_probabilidad` int)
  BEGIN
    DECLARE _idEnemigo, _idMaterial INT;

    SET _idEnemigo = (SELECT ID FROM Enemigos WHERE Nombre = nombreEnemigo);
    SET _idMaterial = (SELECT ID FROM Materiales WHERE Nombre = nombreMaterial);
    INSERT INTO Enemigos_Materiales (ID_Enemigo, ID_Material, Cantidad, Probabilidad) VALUE (_idEnemigo, _idMaterial, _cantidad, _probabilidad);
  END;

