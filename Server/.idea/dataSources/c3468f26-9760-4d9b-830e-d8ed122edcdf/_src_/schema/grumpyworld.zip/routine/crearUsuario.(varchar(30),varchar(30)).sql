CREATE PROCEDURE crearUsuario(IN usuario VARCHAR(30), IN contrasena VARCHAR(30))
  BEGIN
	DECLARE ultimo_id INT;
	IF(!(SELECT existeUsuario(usuario))) THEN
    BEGIN
		INSERT INTO Usuarios (Usuario, Contrasena) VALUE (usuario, contrasena);
        SET ultimo_id = LAST_INSERT_ID();
        INSERT INTO Rollos(ID_Usuario, ID_Zona) SELECT ultimo_id, ID FROM Zonas;
        -- SELECT 1 INTO conseguido;
    END;
    END IF;
    
END;
