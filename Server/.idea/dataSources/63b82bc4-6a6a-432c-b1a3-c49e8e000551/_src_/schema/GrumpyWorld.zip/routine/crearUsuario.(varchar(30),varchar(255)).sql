CREATE PROCEDURE crearUsuario(IN usuario VARCHAR(30), IN contrasena VARCHAR(255), OUT conseguido BIT)
  BEGIN
    INSERT INTO Usuarios (Usuario, Contrasena) VALUE (usuario, contrasena);
    IF(ROW_COUNT()>0) THEN
    BEGIN
		INSERT INTO Rollos(ID_Usuario, ID_Zona) SELECT LAST_INSERT_ID(), ID FROM Zonas WHERE Nombre='bano';
        SELECT 1 INTO conseguido;
    END;
    END IF;
    
END;
