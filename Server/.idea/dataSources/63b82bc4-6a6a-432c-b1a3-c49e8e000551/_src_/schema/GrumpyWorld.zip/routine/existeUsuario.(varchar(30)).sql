CREATE FUNCTION existeUsuario(nombre_usuario VARCHAR(30))
  RETURNS BIT
  BEGIN
  /*DECLARE existe BIT;
  SET existe = FALSE;
    IF((SELECT COUNT(*) FROM Usuarios WHERE Usuario = nombre_usuario)>0) THEN
    BEGIN
		SET existe = TRUE;
    END;
    END IF;*/
	RETURN (SELECT COUNT(*) FROM Usuarios WHERE Usuario = nombre_usuario)>0;
END;
